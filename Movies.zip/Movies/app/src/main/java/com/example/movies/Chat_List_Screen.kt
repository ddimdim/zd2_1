package com.example.movies

import android.app.Activity
import android.os.Bundle
import com.example.movies.databinding.ActivityChatListScreenBinding

class Chat_List_Screen : Activity() {

    private lateinit var binding: ActivityChatListScreenBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityChatListScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

    }
}